import Alamofire
import UIKit
import HealthKit
import SwiftyJSON

let healthKitStore: HKHealthStore = HKHealthStore()

class DashboardViewController: UIViewController {

    
    override func viewDidLoad() {
       // HealthKitManager.activateLongRunningQuery()
    }
    
}
